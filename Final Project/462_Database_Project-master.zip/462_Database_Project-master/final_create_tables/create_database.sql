create database project;
use project;
source create_table.sql;
