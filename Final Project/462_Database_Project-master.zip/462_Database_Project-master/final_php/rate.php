<html>
<body>
<form action="receive_rate.php" method="post">

Title : <input type="text" name="title">
<pre>&nbsp</pre>
Year : <input type="text" name="year">
<pre>&nbsp</pre>
<input type="submit" value="提交">
</form>
<form action="info.php" method="post">
<input type="submit" value='回到主畫面'>
</form>
</body>
</html>