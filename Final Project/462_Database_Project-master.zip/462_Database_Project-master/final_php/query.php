<html>
<body>

<form action="annual_best_movie.php" method="post">
<input type="submit" value="年度最佳電影">
</form>
<form action="annual_worst_movie.php" method="post">
<input type="submit" value="年度最差電影">
</form>
<form action="avg_rating_of_director.php" method="post">
<input type="submit" value="導演作品平均得分(作品數量>30)">
</form>
<form action="best&worst_directors.php" method="post">
<input type="submit" value="最高分＆最低分的導演">
</form>
<form action="biggest_winner_golden_globe.php" method="post">
<input type="submit" value="各年金球獎最大贏家">
</form>
<form action="biggest_winner_oscar.php" method="post">
   <input type="submit" value="各年奧斯卡獎最大贏家">
</form>
<form action="both_sex_rating>9_TOP10.php" method="post">
<input type="submit" value="男性女性評分皆>9的前10部電影">
</form>
<form action="country_best_movie.php" method="post">
<input type="submit" value="各國最佳電影">
</form>
<form action="director_specified_genre.php" method="post">
<input type="submit" value="各導演最擅長的電影類型(作品數量>30)">
</form>
<form action="duration<120_TOP10.php" method="post">
<input type="submit" value="片長<120分鐘的前10名電影">
</form>
<form action="duration_ranking.php" method="post">
<input type="submit" value="3種片長區間的電影平均評分">
</form>
<form action="favorite_genre.php" method="post">
<input type="submit" value="各性別評分最高的電影類型">
</form>
<form action="female_male_favorite_genre.php" method="post">
<input type="submit" value="各性別各年齡層評分最高的電影類型">
</form>
<form action="longest_career_director.php" method="post">
<input type="submit" value="導演職業生涯長度排行榜">
</form>
<form action="masterpiece_of_directors.php" method="post">
<input type="submit" value="導演生涯代表作(作品數量>30)">
</form>
<form action="most_genre_gloden_globe.php" method="post">
<input type="submit" value="金球獎得獎數量最多的電影類型">
</form>
<form action="most_genre_oscar.php" method="post">
<input type="submit" value="奧斯卡獎得獎數量最多的電影類型">
</form>
<form action="Most_movie_of_each_country.php" method="post">
<input type="submit" value="各國電影數量排行榜">
</form>
<form action="most_movie_rating>=8_top5_year.php" method="post">
<input type="submit" value="出產最多評分>8電影的前5年">
</form>
<form action="most_produce_ten_years.php" method="post">
<input type="submit" value="出產電影數量前10多的年份">
</form>
<form action="most_prolific_genre.php" method="post">
<input type="submit" value="拍攝最多的電影類型">
</form>
<form action="most_win_director.php" method="post">
<input type="submit" value="得過最多獎項的導演">
</form>
<form action="num_of_movie_duration.php" method="post">
<input type="submit" value="各片長區間的電影數量">
</form>
<form action="pity_movie_gg.php" method="post">
<input type="submit" value="金球獎最大遺珠">
</form>
<form action="pity_movie_oscar.php" method="post">
<input type="submit" value="奧斯卡獎最大遺珠">
</form>
<form action="ten_years_BEST_PICTURE.php" method="post">
<input type="submit" value="近十年的奧斯卡金像獎最佳影片得主">
</form>
<form action="The_country_producing_best_movie.php" method="post">
<input type="submit" value="優質電影出產國排行榜 (電影數量>100)">
</form>
<form action="top3_popular_genre_of_different_age.php" method="post">
<input type="submit" value="最受各年齡層歡迎的電影類型">
</form>
<form action="top10_short_film.php" method="post">
<input type="submit" value="前十大短片(片長<90分鐘)">
</form>
<form action="top100_popular_movie.php" method="post">
<input type="submit" value="最受歡迎Top 100(投票數量)">
</form>
<form action="Top_5_years_having_the_best_quality_of_movies.php" method="post">
<input type="submit" value="出產電影品質最高的5年">
</form>
<form action="Top_100.php" method="post">
   <input type="submit" value="各性別及綜合評分Top 100">
</form>
<form action="Top_100_movies_of_age.php" method="post">
<input type="submit" value="各年齡層評分Top 100">
</form>
<form action="TOP3_Prolific_Directors.php" method="post">
<input type="submit" value="最多產的導演排行榜">
</form>
<form action="TOP3_rating_genre.php" method="post">
<input type="submit" value="各電影種類平均評分排行榜">
</form>
<form action="Top_movies_in_10_years.php" method="post">
<input type="submit" value="近10年出產的最佳電影">
</form>
<form action="info.php" method="post">
<input type="submit" value='回到主畫面'>
</form>
</body>
</html>