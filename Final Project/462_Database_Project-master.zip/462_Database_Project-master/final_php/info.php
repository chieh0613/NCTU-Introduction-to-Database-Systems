<html>
<body>
<form action="query.php" method="post">
<input type="submit" value="統計數據">
</form>
<form action="post.php" method="post">
<input type="submit" value="條件查詢">
</form>
<form action="rate.php" method="post">
<input type="submit" value="我要評分">
</form>





</body>
</html>
