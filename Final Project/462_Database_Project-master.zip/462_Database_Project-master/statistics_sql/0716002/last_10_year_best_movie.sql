/*近10年BEST PICTURE*/
SELECT o.film
FROM oscar o
ORDER BY o.year DESC limit 10;