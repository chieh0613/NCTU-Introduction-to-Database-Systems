<html>
<body>
<form action="Top_100.php" method="post">
   <input type="submit" value="Top 100">
</form>
<form action="biggest_winner_oscar.php" method="post">
   <input type="submit" value="biggest_winner_oscar">
</form>
</form>
<form action="TOP3_rating_genre.php" method="post">
<input type="submit" value="TOP3_rating_genre">
</form>
<form action="most_movie_rating>=8_top5_year.php" method="post">
<input type="submit" value="most_movie_rating>=8 _top5_year">
</form>
</form>
<form action="best&worst_directors.php" method="post">
<input type="submit" value="best&worst_directors">
</form>
</form>
<form action="masterpiece_of_directors.php" method="post">
<input type="submit" value="masterpiece_of_directors">
</form>
<form action="avg_rating_of_director.php" method="post">
<input type="submit" value="avg_rating_of_director">
</form>
<form action="both_sex_rating>9_TOP10.php" method="post">
<input type="submit" value="both_sex_rating>9_TOP10">
</form>
<form action="duration<120_TOP10.php" method="post">
<input type="submit" value="duration<120_TOP10">
</form>
<form action="female_male_favorite_genre.php" method="post">
<input type="submit" value="female_male_favorite_genre">
</form>
<form action="most_genre_oscar.php" method="post">
<input type="submit" value="most_genre_oscar">
</form>
<form action="favorite_genre.php" method="post">
<input type="submit" value="favorite_genre">
</form>
</form>
<form action="most_genre_gloden_globe.php" method="post">
<input type="submit" value="most_genre_gloden_globe">
</form>
<form action="ten_years_BEST_PICTURE.php" method="post">
<input type="submit" value="ten_years_BEST_PICTURE">
</form>
<form action="most_win_director.php" method="post">
<input type="submit" value="most_win_director">
</form>
<form action="most_produce_ten_years.php" method="post">
<input type="submit" value="most_produce_ten_years">
</form>
<form action="most_prolific_genre.php" method="post">
<input type="submit" value="most_prolific_genre">
</form>
<form action="biggest_winner_golden_globe.php" method="post">
<input type="submit" value="biggest_winner_golden_globe">
</form>
<form action="Most_movie_of_each_country.php" method="post">
<input type="submit" value="Most_movie_of_each_country">
</form>
<form action="The_country_producing_best_movie.php" method="post">
<input type="submit" value="The_country_producing_best_movie">
</form>
<form action="Top_5_years_having_the_best_quality_of_movies.php" method="post">
<input type="submit" value="Top_5_years_having_the_best_quality_of_movies">
</form>
<form action="Top_100_movies_of_age.php" method="post">
<input type="submit" value="Top_100_movies_of_age">
</form>
<form action="Top_movies_in_10_years.php" method="post">
<input type="submit" value="Top_movies_in_10_years">
</form>
<form action="best_movie_top5.php" method="post">
<input type="submit" value="best_movie_top5">
</form>
</form>
<form action="annual_best_movie.php" method="post">
<input type="submit" value="annual_best_movie">
</form>
<form action="annual_worst_movie.php" method="post">
<input type="submit" value="annual_worst_movie">
</form>
</form>
<form action="country_best_movie.php" method="post">
<input type="submit" value="country_best_movie">
</form>
</form>
<form action="director_specified_genre.php" method="post">
<input type="submit" value="director_specified_genre">
</form>
</form>
<form action="duration_ranking.php" method="post">
<input type="submit" value="duration_ranking">
</form>
</form>
<form action="longest_career_director.php" method="post">
<input type="submit" value="longest_career_director">
</form>
</form>
<form action="num_of_movie_duration.php" method="post">
<input type="submit" value="num_of_movie_duration">
</form>
</form>
<form action="pity_movie_gg.php" method="post">
<input type="submit" value="pity_movie_gg">
</form>
</form>
<form action="pity_movie_oscar.php" method="post">
<input type="submit" value="pity_movie_oscar">
</form>
</form>
<form action="top3_popular_genre_of_different_age.php" method="post">
<input type="submit" value="top3_popular_genre_of_different_age">
</form>
</form>
<form action="top10_short_film.php" method="post">
<input type="submit" value="top10_short_film">
</form>
</form>
<form action="top100_popular_movie.php" method="post">
<input type="submit" value="top100_popular_movie">
</form>
</form>
<form action="TOP3_Prolific_Directors.php" method="post">
<input type="submit" value="TOP3_Prolific_Directors">
</form>






</body>
</html>