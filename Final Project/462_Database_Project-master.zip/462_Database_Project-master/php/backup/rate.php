<html>
<body>
<form action="receive_rate.php" method="post">

title : <input type="text" name="title">
<pre>&nbsp</pre>
<input type="submit" value="submit">
</form>
</body>
</html>
