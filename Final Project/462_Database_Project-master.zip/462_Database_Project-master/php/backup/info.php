<html>
<body>
<form action="query.php" method="post">
<input type="submit" value="static">
</form>
<form action="post.php" method="post">
<input type="submit" value="dynamic">
</form>
<form action="rate.php" method="post">
<input type="submit" value="rate">
</form>





</body>
</html>
